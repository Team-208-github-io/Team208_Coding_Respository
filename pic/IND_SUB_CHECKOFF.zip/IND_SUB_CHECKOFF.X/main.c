#include <stdbool.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdint.h>
#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/spi2.h"
#include "mcc_generated_files/examples/i2c1_master_example.h"
#define address 0b1001100 //hex 0x4C //hex through hole 0x48
#define tempreg 0x00

/*
void main(void) {
    
    SYSTEM_Initialize();
    EUSART1_Initialize();
    SPI2_Initialize();
    TMR2_Initialize();
    SPI2_Open(SPI2_DEFAULT);
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    
    uint24_t Force=0; 
    uint8_t configRegValue = 0b01000111;
    //SPI2_ExchangeByte(configRegValue);
    SPI2_WriteByte(configRegValue);
    //uint8_t Com_Ch0 =  0b01000001;
    uint8_t Com_Ch1 =  0b01001101;
    
    
    while (1){       
        LED_1_Toggle();
        FORCE_CS_SetLow();
        __delay_ms(50); 
        //printf("1\r");
        //SPI2_ExchangeByte(Com_Ch1);
        //printf("2\r");
        SPI2_WriteByte(Com_Ch1);
        __delay_ms(50);
        Force = SPI2_ReadByte();
        __delay_ms(50);
        LED_1_Toggle();               
        FORCE_CS_SetHigh();
        __delay_ms(50);
        
        if(EUSART1_is_tx_ready()){
            printf("Force: %d\r",Force);
            LED_2_Toggle();
        }
        SPI2_Close();
        
    }
}  
*/

/*
volatile uint8_t rxdata;


void EUSART1_ISR(char txdata)
{
    EUSART1_Receive_ISR();
    
    if(EUSART1_is_rx_ready()){
        
        rxdata = EUSART1_Read();
    
        EUSART1_Write(txdata);
        LED1_Toggle();
        

    }
    
}
*/

/*
void main(void)
{
    
    SYSTEM_Initialize();
    EUSART1_Initialize();
    SPI2_Initialize();
    TMR2_Initialize();
    
    
    
    LED1_SetLow();
    
    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    uint24_t Force; 
    
    uint8_t Com_Ch0 =  0b00000000;
    uint8_t Com_Ch1 =  0b01001101;
    
    
    while (1)
    {
        LED1_Toggle();
        SPI2_Open(SPI2_DEFAULT);
        FORCE_CS_SetLow();
        __delay_ms(50);
        __delay_ms(1000);
        Force=SPI2_ExchangeByte(Com_Ch0);
        __delay_ms(50);
        LED1_Toggle();
        
        LED2_Toggle();
        FORCE_CS_SetHigh();
        __delay_ms(50);
        SPI2_Close();
        __delay_ms(1000);
        LED2_Toggle();
        
        
        
        if(EUSART1_is_tx_ready()){
            printf("Force: %u\r",Force);
            LED2_Toggle();
        }
        __delay_ms(1000);
        
        
        
        
    }
}
 */

void main(void)
{
    SYSTEM_Initialize();
    EUSART1_Initialize();
    SPI2_Initialize();
    TMR2_Initialize(); 
    I2C1_Initialize();
    SPI2_Open(SPI2_DEFAULT);
    
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    
    uint24_t Force=0; 
    uint8_t configRegValue = 0b01000111;
    //SPI2_ExchangeByte(configRegValue);
    SPI2_WriteByte(configRegValue);
    //uint8_t Com_Ch0 =  0b01000001;
    uint8_t Com_Ch1 =  0b01001101;
    
    
   
    
    //PWM6_Initialize();
    uint8_t readtemp;
    uint8_t temp;
    uint8_t temp_max = 30;
    DIS_SetLow();
    
    //PWM6_LoadDutyValue(255);
    
    while (1)
        
    {
        
    
        LED_1_Toggle();
        
        if(EUSART1_is_tx_ready())
        {
            LED_2_Toggle();
            readtemp = I2C1_Read1ByteRegister(address, tempreg);
            temp = (readtemp*1.8)+32;
            printf ("TEMP = %uC or %uF\r\n", readtemp,temp);
            __delay_ms(1000);
  
        }
        LED_1_Toggle();
        FORCE_CS_SetLow();
        __delay_ms(50); 
        //printf("1\r");
        //SPI2_ExchangeByte(Com_Ch1);
        //printf("2\r");
        SPI2_WriteByte(Com_Ch1);
        __delay_ms(50);
        Force = SPI2_ReadByte();
        __delay_ms(50);
        LED_1_Toggle();               
        FORCE_CS_SetHigh();
        __delay_ms(50);
        
        if(EUSART1_is_tx_ready()){
            printf("Force: %d\r",Force);
            LED_2_Toggle();
        }
        SPI2_Close();
        __delay_ms(2000);
        
        if(readtemp>=temp_max)
        {
            
            LED_3_Toggle();
            DIR_Toggle();
         /*
            SPI2_Open(SPI2_DEFAULT);
            MOTORCS_SetLow();
            Motor=SPI2_ExchangeByte(Forward);
            LED_1_Toggle();
            MOTORCS_SetHigh();
            SPI2_Close();
            __delay_ms(1000);   
            LED_1_Toggle();
        
        */
        }
        else
        {
            /*
            LED_3_Toggle();
            DIR_Toggle();
            
            SPI2_Open(SPI2_DEFAULT);
            MOTORCS_SetLow();
            Motor=SPI2_ExchangeByte(Backward);
            LED_2_Toggle();
            MOTORCS_SetHigh();
            SPI2_Close();
            __delay_ms(1000);
            LED_2_Toggle();
            */
        }  
    }
}
